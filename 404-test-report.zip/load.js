const axios = require('axios');
const { performance } = require('perf_hooks');

const VUs = 5; // Number of virtual users (adjust based on system capacity)
const DURATION = 30000; // Test duration (30s)
const INITIAL_SLEEP_INTERVAL = 1000; // Initial delay between requests (1s)
const MAX_SLEEP_INTERVAL = 10000; // Max backoff (10s)
const RETRY_LIMIT = 3; // Maximum retries per request

async function sendRequestWithRetry(retries = 0) {
    const start = performance.now();
    try {
        const response = await axios.get('https://www.xenonstack.com/');
        const duration = performance.now() - start;
        
        console.log(`✅ Status 200: ${response.status === 200}, Response time < 3s: ${duration < 3000} (${duration.toFixed(2)}ms)`);
        return true; // Success
    } catch (error) {
        if (error.response && error.response.status === 429) {
            console.warn(`⏳ Rate limited (429), retrying (${retries + 1}/${RETRY_LIMIT})...`);
            if (retries < RETRY_LIMIT) {
                await new Promise(resolve => setTimeout(resolve, INITIAL_SLEEP_INTERVAL * (retries + 1))); // Incremental backoff
                return sendRequestWithRetry(retries + 1);
            }
        } else {
            console.error(`❌ Request failed: ${error.message}`);
        }
        return false; // Failure
    }
}

async function loadTest() {
    const startTime = Date.now();
    const endTime = startTime + DURATION;
    let sleepInterval = INITIAL_SLEEP_INTERVAL;

    while (Date.now() < endTime) {
        const requests = [];
        for (let i = 0; i < VUs; i++) {
            requests.push(sendRequestWithRetry());
        }

        await Promise.all(requests); // Wait for all VUs to complete before starting the next batch
        await new Promise(resolve => setTimeout(resolve, sleepInterval)); // Sleep between request batches
    }

    console.log('🚀 Load test completed.');
}

// Run the load test
loadTest().catch(error => {
    console.error(`❌ Load test encountered an error: ${error}`);
});
